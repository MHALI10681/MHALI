# ফ্রি ওয়েবসাইট হোস্টিং গাইড

## ১. GitHub Pages (সবচেয়ে জনপ্রিয়)

### ধাপসমূহ:

**ধাপ ১: GitHub অ্যাকাউন্ট তৈরি করুন**
- https://github.com এ যান
- "Sign up" ক্লিক করুন
- আপনার ইমেইল, পাসওয়ার্ড দিয়ে রেজিস্ট্রেশন করুন

**ধাপ ২: নতুন Repository তৈরি করুন**
- উপরে ডানদিকে "+" চিহ্নে ক্লিক করুন
- "New repository" সিলেক্ট করুন
- Repository name: `your-username.github.io` (আপনার ইউজারনেম দিয়ে)
- Public সিলেক্ট করুন
- "Create repository" ক্লিক করুন

**ধাপ ৩: ফাইল আপলোড করুন**
- "uploading an existing file" লিংকে ক্লিক করুন
- index.html ফাইলটি ড্র্যাগ করে আনুন
- "Commit changes" ক্লিক করুন

**ধাপ ৪: ওয়েবসাইট দেখুন**
- কয়েক মিনিট পর এই ঠিকানায় যান: `https://your-username.github.io`
- আপনার ওয়েবসাইট লাইভ!

**সুবিধা:**
✅ সম্পূর্ণ ফ্রি
✅ কাস্টম ডোমেইন যুক্ত করা যায়
✅ HTTPS সাপোর্ট
✅ খুবই দ্রুত এবং নির্ভরযোগ্য
✅ কোন বিজ্ঞাপন নেই

---

## ২. Netlify (সহজ এবং শক্তিশালী)

### ধাপসমূহ:

**ধাপ ১: অ্যাকাউন্ট তৈরি**
- https://www.netlify.com এ যান
- "Sign up" ক্লিক করুন
- GitHub/Email দিয়ে সাইন আপ করুন

**ধাপ ২: সাইট Deploy করুন**
- Dashboard এ "Add new site" ক্লিক করুন
- "Deploy manually" সিলেক্ট করুন
- আপনার প্রজেক্ট ফোল্ডার ড্র্যাগ করে আনুন
- Deploy হয়ে যাবে!

**ধাপ ৩: লাইভ URL পাবেন**
- Netlify একটি র‍্যান্ডম URL দেবে (যেমন: random-name-123.netlify.app)
- Settings থেকে কাস্টম নাম দিতে পারবেন

**সুবিধা:**
✅ ড্র্যাগ & ড্রপ deploy
✅ অটোমেটিক HTTPS
✅ ফ্রি কাস্টম ডোমেইন
✅ দ্রুত CDN
✅ ফর্ম সাবমিশন সাপোর্ট

---

## ৩. Vercel (আধুনিক এবং দ্রুত)

### ধাপসমূহ:

**ধাপ ১: সাইন আপ**
- https://vercel.com এ যান
- "Sign up" ক্লিক করুন
- GitHub দিয়ে সাইন আপ করুন (সুপারিশকৃত)

**ধাপ ২: প্রজেক্ট Import করুন**
- "Add New" → "Project" ক্লিক করুন
- "Browse" বা GitHub repository সিলেক্ট করুন
- "Deploy" ক্লিক করুন

**ধাপ ৩: লাইভ**
- কয়েক সেকেন্ডেই ডিপ্লয় হয়ে যাবে
- `.vercel.app` URL পাবেন

**সুবিধা:**
✅ সবচেয়ে দ্রুত ডিপ্লয়মেন্ট
✅ অটোমেটিক প্রিভিউ
✅ কাস্টম ডোমেইন ফ্রি
✅ অসাধারণ পারফরম্যান্স

---

## ৪. InfinityFree (PHP এবং MySQL সাপোর্ট)

### যদি PHP এবং Database দরকার হয়:

**ধাপ ১:**
- https://infinityfree.net এ যান
- "Sign Up" ক্লিক করুন

**ধাপ ২:**
- ফ্রি subdomain বা কাস্টম ডোমেইন সিলেক্ট করুন
- অ্যাকাউন্ট তৈরি করুন

**ধাপ ৩:**
- cPanel এ লগইন করুন
- File Manager দিয়ে ফাইল আপলোড করুন
- htdocs ফোল্ডারে index.html রাখুন

**সুবিধা:**
✅ PHP সাপোর্ট
✅ MySQL ডাটাবেস
✅ Unlimited bandwidth
✅ cPanel access

---

## ৫. Render (ব্যাকএন্ড এর জন্যও ভালো)

**দ্রুত পদক্ষেপ:**
1. https://render.com এ যান
2. Sign up করুন
3. "New Static Site" ক্লিক করুন
4. GitHub repository connect করুন
5. Deploy!

---

## সেরা পরামর্শ:

### শুরুতে যারা আছেন তাদের জন্য:
→ **GitHub Pages** ব্যবহার করুন (সবচেয়ে সহজ এবং নির্ভরযোগ্য)

### দ্রুত deploy চাইলে:
→ **Netlify** বা **Vercel** ব্যবহার করুন

### PHP/Database দরকার হলে:
→ **InfinityFree** বা **000webhost**

---

## কমান্ড লাইন দিয়ে GitHub Pages (Advanced):

```bash
# Git install করুন তারপর:

git init
git add .
git commit -m "First commit"
git branch -M main
git remote add origin https://github.com/username/username.github.io.git
git push -u origin main
```

---

## গুরুত্বপূর্ণ টিপস:

1. **ফাইলের নাম** অবশ্যই `index.html` হতে হবে
2. সব ফাইল **lowercase** এ রাখুন
3. ফোল্ডার স্ট্রাকচার সঠিক রাখুন
4. কাস্টম ডোমেইন যুক্ত করতে চাইলে DNS সেটিংস করতে হবে
5. HTTPS অটোমেটিক চালু হয় (GitHub Pages, Netlify, Vercel এ)

---

## যদি সমস্যা হয়:

- ফাইল আপলোড না হলে → ব্রাউজার রিফ্রেশ করুন
- ওয়েবসাইট দেখা না গেলে → ৫-১০ মিনিট অপেক্ষা করুন
- 404 Error → index.html নাম চেক করুন
- ডোমেইন কাজ না করলে → DNS propagation এর জন্য ২৪ ঘণ্টা অপেক্ষা করুন

---

**সফলতার সাথে আপনার ওয়েবসাইট হোস্ট হয়ে যাবে! 🎉**
